#include<signal.h>
#include<unistd.h>

#include<stdio.h>
#include<stdlib.h>

void send_signal(int signo){
    if(signo == SIGINT)
    printf("Signal recived..!");
    
    return;
}

int main(void){
    pid_t pid, ppid;

    ppid = getpid();
    printf("ppid = %d\n", ppid);

    if((pid = fork()) == 0){ 
        sleep(2);
        printf("Killing_Parent......\n");

        kill(ppid, SIGINT);
        printf("After_killing_Parent.......\n");
    }

    else
    {
        printf("%d %d ",ppid, pid);
        if(signal(SIGINT,send_signal) == SIG_ERR)
            printf("Signal_Processed Done ");
        sleep(3);
    }

    return 0;
}